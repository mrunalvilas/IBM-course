import java.io.Serializable;
import java.time.LocalDate;

// single recycling event for a household
public class RecyclingEvent implements Serializable{
    private String materialType;
    private double weight;
    private double ecoPoints;
    private LocalDate date;

    public RecyclingEvent(String materialType, double weight){
        this.materialType = materialType;
        this.weight = weight;
        this.date = LocalDate.now();
        this.ecoPoints = weight * 10;
    }

    public String getMaterialType(){
        return this.materialType;
    }

    public double getWeight(){
        return this.weight;
    }
    public LocalDate getDate(){
        return this.date;
    }

    public double getEcoPoints(){
        return this.ecoPoints;
    }

    public String toString(){
        return "--------------------------------------"+
        "\n| Date: "+this.date+" | Material Type: "+
        this.materialType + "| Weight: "+ this.weight + 
        " | EcoPoints: "+this.ecoPoints + " |"+
        "\n--------------------------------------";
    }
}